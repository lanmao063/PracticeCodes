package aclass;

public class lottery 
{
	private person pr;
	private machine ma;
	public lottery()
	{
		pr=new person();
		ma=new machine();
	}
	public void play()
	{
		System.out.println("请输入彩票号码（1~35）：");
		pr.input();
		System.out.println("正在生成中奖号码……");
		ma.chooseNum();
		System.out.println("彩票机生成的中奖号码是：");
		ma.printNum();
		if(compare.result(pr.getInput(),ma.getMachine()))
		{
			System.out.println("恭喜您中奖了");
		}
		else
		{
			System.out.println("很抱歉您没中奖");
		}
	}
	public static void main(String[] args) 
	{
		lottery game=new lottery();
		game.play();
	}

}
