package aclass;

public class rank {
	private int[] array;
	public rank(int[] array)
	{
		this.array=array;
	}
	public int[] bubble(int[] inputArray)
	{
		for(int i=0;i<array.length-1;i++)
		{
			for(int j=0;j<array.length-i-1;j++)
			{
				if(array[j]>array[j+1])
				{
					int temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		return array;
	}
}
