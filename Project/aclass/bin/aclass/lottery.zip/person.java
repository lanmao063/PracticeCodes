package aclass;
import java.util.Scanner;
public class person 
{
	private int[] number=new int[7];
	private int[] rankedNumber =new int[7];
	public void input()
	{
		for(int k=0;k<number.length;k++) 
		{ 
	        Scanner in = new Scanner(System.in);
			number[k] = in.nextInt();
		}
		rank r=new rank(number);
		rankedNumber=r.bubble(number);
	}
	public int[] getInput()
	{
		return rankedNumber;
	}

}
