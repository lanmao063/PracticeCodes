package aclass;

import java.util.Random;
import java.util.Set;
import java.util.HashSet;
public class machine 
{
	private int [] number= new int[7];
	private int[] rankedNumber=new int[7];
	public void chooseNum()
	{
		Random random=new Random();
		Set<Integer> set=new HashSet<>();  
	    int i=0;
	    while (i<7) 
	    {
	        int index=random.nextInt(1,36);
	        if (!set.contains(index)) 
	        {
	            set.add(index);
	            number[i] = index;
	            i++;
	        }
	    }
		rank r = new rank(number);	
		rankedNumber=r.bubble(number);
	}
	
	public int[] getMachine()
	{
		return rankedNumber;
	}
	public void printNum()
	{
		for(int i:rankedNumber)
		{
			System.out.println(i);
		}
	}
//	public static void main(String[] args) {
//		
//	}

}
