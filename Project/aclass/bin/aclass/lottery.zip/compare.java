package aclass;

public class compare 
{
	public static boolean result(int[] userNumbers,int[] machineNumbers) 
	{ 
		for(int i=0;i<userNumbers.length;i++)
		{
			if(userNumbers[i]!=machineNumbers[i])
			{
				return false;
			}
			
		}
		return true;
	}

	

		
	
}

